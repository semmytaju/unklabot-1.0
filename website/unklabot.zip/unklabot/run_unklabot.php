<?php
	// POST Data
	$data['user-question'] = $_POST['input-chat'];

	// execute python script 
	$pythonScript = "C:/xampp/htdocs/unklabot/unklabot.py";
	exec('python '.$pythonScript.' "'.$data['user-question'].'"', $output);

	// print output obtained by Python script
	foreach ($output as $line) {
		echo $line;
	}
?>